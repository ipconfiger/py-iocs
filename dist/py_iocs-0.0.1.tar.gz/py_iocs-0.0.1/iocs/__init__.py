from .container import IocContainer
__all__ = ['IocContainer']
